package com.ridzsensix;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import rikka.shizuku.Shizuku;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private boolean shizukuReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        startService(new Intent(this, OverlayService.class));

        webView = findViewById(R.id.webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");

        if (Shizuku.pingBinder()) {
            shizukuReady = true;
            webView.loadUrl("javascript:updateShizukuStatus(true)");
        } else {
            Shizuku.requestPermission(0);
        }
    }

    private class AndroidBridge {
        @JavascriptInterface public void sendLog(String msg) {
            Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
        }
        @JavascriptInterface public void launchFreeFire() {
            Toast.makeText(MainActivity.this, "Launch Free Fire!", Toast.LENGTH_SHORT).show();
        }
        @JavascriptInterface public void getShizukuStatus() {
            if (shizukuReady) webView.loadUrl("javascript:updateShizukuStatus(true)");
            else webView.loadUrl("javascript:updateShizukuStatus(false)");
        }
    }
}
